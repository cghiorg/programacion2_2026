from flask import Flask, render_template, request

app = Flask(__name__)

@app.route("/")
def inicio():
    return render_template("index.html")


@app.route("/registrar", methods=["POST"])
def registrar():
    nombre = request.form["nombre"]
    apellido = request.form["apellido"]
    carrera = request.form["carrera"]
    edad = request.form["edad"]

    return render_template(
        "resultado.html",
        nombre=nombre,
        apellido=apellido,
        carrera=carrera,
        edad=edad
    )


if __name__ == "__main__":
    app.run(debug=True)